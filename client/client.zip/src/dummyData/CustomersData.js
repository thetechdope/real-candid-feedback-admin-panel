const CustomersData = [
  {
    id: 1,
    month: "Jan",
    noOfCustomersGained: 456,
    noOfCustomersLost: 76,
  },
  {
    id: 2,
    month: "Feb",
    noOfCustomersGained: 716,
    noOfCustomersLost: 23,
  },
  {
    id: 3,
    month: "Mar",
    noOfCustomersGained: 765,
    noOfCustomersLost: 50,
  },
  {
    id: 4,
    month: "Apr",
    noOfCustomersGained: 600,
    noOfCustomersLost: 36,
  },
  {
    id: 5,
    month: "May",
    noOfCustomersGained: 675,
    noOfCustomersLost: 401,
  },
  {
    id: 6,
    month: "Jun",
    noOfCustomersGained: 345,
    noOfCustomersLost: 787,
  },
  {
    id: 7,
    month: "Jul",
    noOfCustomersGained: 800,
    noOfCustomersLost: 10,
  },
];

export default CustomersData;
